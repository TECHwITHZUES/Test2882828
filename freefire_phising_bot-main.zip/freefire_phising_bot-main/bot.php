<?php

$token = "YOUR_BOT_TOKEN";
$data = [
    'text' => $msg,
    'chat_id' => 'YOUR_CHAT_ID'
];

?>